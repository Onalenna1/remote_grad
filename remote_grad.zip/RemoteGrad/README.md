# RemoteGrad

A MERN-stack job board: React frontend + Express/MongoDB backend.

## Backend

```
cd backend
npm install
cp .env.example .env   # then fill in MONGO_URI and JWT_SECRET
npm run dev
```

Runs on http://localhost:5000 by default.

## Frontend

```
cd frontend
npm install
npm start
```

Runs on http://localhost:3000 and talks to the backend at http://localhost:5000.

Register an account, log in, then browse `/jobs`, apply, and check `/applications` and `/profile`.
