import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Jobs from './components/Jobs';
import Applications from './components/MyApplications';
import Profile from './components/Profile';
import Navigation from './components/Navigation';

function App() {
  const isAuthenticated = !!localStorage.getItem('token');

  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/jobs" element={isAuthenticated ? <Jobs /> : <Navigate to="/login" />} />
        <Route path="/applications" element={isAuthenticated ? <Applications /> : <Navigate to="/login" />} />
        <Route path="/profile" element={isAuthenticated ? <Profile /> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/jobs" />} />
      </Routes>
    </Router>
  );
}

export default App;