import React from 'react';
import { Link } from 'react-router-dom';

function Navigation() {
  const handleLogout = () => {
    localStorage.removeItem('token');
    window.location.href = '/login';
  };
  
  return (
    <nav style={{ padding: '10px', borderBottom: '1px solid #ccc' }}>
      <Link to="/jobs" style={{ marginRight: '10px' }}>Jobs</Link>
      <Link to="/applications" style={{ marginRight: '10px' }}>My Applications</Link>
      <Link to="/profile" style={{ marginRight: '10px' }}>Profile</Link>
      <button onClick={handleLogout}>Logout</button>
    </nav>
  );
}

export default Navigation;