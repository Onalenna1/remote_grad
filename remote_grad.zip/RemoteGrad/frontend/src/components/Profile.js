import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Profile() {
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState({ name: '', email: '' });
  
  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(res.data);
      setForm({ name: res.data.name, email: res.data.email });
    };
    fetchProfile();
  }, []);
  
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  
  const handleUpdate = async () => {
    const token = localStorage.getItem('token');
    try {
      await axios.put('http://localhost:5000/api/profile', form, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert('Profile updated');
    } catch {
      alert('Update failed');
    }
  };
  
  if (!profile) return <p>Loading...</p>;
  
  return (
    <div>
      <h2>Edit Profile</h2>
      <input
        name="name"
        value={form.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input
        name="email"
        value={form.email}
        onChange={handleChange}
        placeholder="Email"
      />
      <button onClick={handleUpdate}>Save Changes</button>
    </div>
  );
}

export default Profile;