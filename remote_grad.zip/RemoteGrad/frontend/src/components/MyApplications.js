import React, { useEffect, useState } from 'react';
import axios from 'axios';

function MyApplications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const fetchApplications = async () => {
    const token = localStorage.getItem('token');
    const res = await axios.get('http://localhost:5000/api/applications/me', {
      headers: { Authorization: `Bearer ${token}` },
    });
    setApplications(res.data);
    setLoading(false);
  };
  
  useEffect(() => {
    fetchApplications();
  }, []);
  
  const handleCancel = async (appId) => {
    const token = localStorage.getItem('token');
    try {
      await axios.delete(`http://localhost:5000/api/applications/${appId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setApplications(applications.filter((app) => app._id !== appId));
      alert('Application canceled');
    } catch {
      alert('Failed to cancel');
    }
  };
  
  if (loading) return <p>Loading...</p>;
  
  return (
    <div>
      <h2>My Applications</h2>
      {applications.length === 0 ? (
        <p>You haven't applied to any jobs yet.</p>
      ) : (
        applications.map((app) => (
          <div key={app._id} style={{ border: '1px solid #ccc', padding: '10px', margin: '10px' }}>
            <h3>{app.jobId.title}</h3>
            <p>Company: {app.jobId.company}</p>
            <p>Location: {app.jobId.location}</p>
            <p>Status: {app.status}</p>
            <p>Applied on: {new Date(app.appliedAt).toLocaleString()}</p>
            <button onClick={() => handleCancel(app._id)}>Cancel Application</button>
          </div>
        ))
      )}
    </div>
  );
}

export default MyApplications;