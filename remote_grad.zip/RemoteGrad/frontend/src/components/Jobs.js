import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Jobs() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      const res = await axios.get('http://localhost:5000/api/jobs/');
      setJobs(res.data);
    };
    fetchJobs();
  }, []);

  const handleApply = async (jobId) => {
    const token = localStorage.getItem('token');
    try {
      await axios.post(
        'http://localhost:5000/api/applications',
        { jobId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Application submitted!');
    } catch (err) {
      alert(err.response?.data?.message || 'Error applying');
    }
  };

  return (
    <div>
      <h2>Verified Remote Jobs</h2>
      {jobs.length === 0 ? (
        <p>No jobs available.</p>
      ) : (
        jobs.map((job) => (
          <div key={job._id} style={{ border: '1px solid #ccc', padding: '10px', margin: '10px' }}>
            <h3>{job.title}</h3>
            <p>{job.description}</p>
            <p>Company: {job.company}</p>
            <p>Location: {job.location}</p>
            <button onClick={() => handleApply(job._id)}>Apply</button>
          </div>
        ))
      )}
    </div>
  );
}

export default Jobs;