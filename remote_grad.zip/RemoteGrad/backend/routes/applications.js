const express = require('express');
const jwt = require('jsonwebtoken');
const Application = require('../models/Application');

const router = express.Router();

// Apply to a job
router.post('/', async (req, res) => {
  const { jobId } = req.body;
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId;
    
    // Check for duplicate application
    const existing = await Application.findOne({ userId, jobId });
    if (existing) return res.status(400).json({ message: 'Already applied' });
    
    const newApp = new Application({ userId, jobId });
    await newApp.save();
    res.json({ message: 'Application submitted' });
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

// Get user's applications
router.get('/me', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId;
    const applications = await Application.find({ userId }).populate('jobId');
    res.json(applications);
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

// Cancel application
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId;
    const app = await Application.findById(id);
    if (!app || app.userId.toString() !== userId) {
      return res.status(404).json({ message: 'Application not found or unauthorized' });
    }
    await Application.findByIdAndDelete(id);
    res.json({ message: 'Application canceled' });
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' });
  }
});

module.exports = router;