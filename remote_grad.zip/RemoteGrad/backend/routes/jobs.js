const express = require('express');
const Job = require('../models/Job');

const router = express.Router();

// Get verified jobs
router.get('/', async (req, res) => {
  const jobs = await Job.find({ verified: true });
  res.json(jobs);
});

// For admin: post a new job
router.post('/post', async (req, res) => {
  const { title, description, company, location } = req.body;
  const newJob = new Job({ title, description, company, location, verified: false }); // verify later
  await newJob.save();
  res.json({ message: 'Job posted, pending verification' });
});

module.exports = router;