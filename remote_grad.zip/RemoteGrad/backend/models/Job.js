const mongoose = require('mongoose');

const JobSchema = new mongoose.Schema({
  title: String,
  description: String,
  company: String,
  location: String,
  verified: { type: Boolean, default: false },
});

module.exports = mongoose.model('Job', JobSchema);